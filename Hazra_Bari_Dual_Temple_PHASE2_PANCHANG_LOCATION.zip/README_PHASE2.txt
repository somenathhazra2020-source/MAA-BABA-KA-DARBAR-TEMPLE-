HAZRA BARI VIRTUAL DUAL TEMPLE — PHASE 2
PANCHANG & LOCATION RELIABILITY
========================================

WHAT THIS PHASE CHANGES
- Home map coordinates are read from HOME_LATITUDE / HOME_LONGITUDE secrets.
- Panchang coordinates can be independently set with PANCHANG_LATITUDE / PANCHANG_LONGITUDE.
- Coordinate pairs and valid latitude/longitude ranges are checked.
- Panchang and astronomy requests use the resolved coordinates.
- The Panchang page displays the selected location and coordinates, rather than claiming every result is for central Durgapur.
- Sunrise/sunset/moonrise/moonset values are not fabricated. If a source fails or a value is missing, the app displays unavailable.
- API credentials remain server-side in Streamlit Secrets; diagnostics do not print the key.
- Existing temple features and PostgreSQL configuration are retained from Phase 1.

STREAMLIT SECRETS
Keep your existing DATABASE_URL and API settings. Add/verify these entries:

HOME_LATITUDE = 23.493261
HOME_LONGITUDE = 87.338363
PANCHANG_API_URL = "https://api.navamsha.in/api/v1/panchang/full"
PANCHANG_API_KEY = "YOUR_ROTATED_NAVAMSHA_KEY"

The Panchang uses the home coordinates by default. If the temple's ritual/astronomical location is different, set both of these separately:
PANCHANG_LATITUDE = 23.493261
PANCHANG_LONGITUDE = 87.338363
PANCHANG_LOCATION_NAME = "Gopinathpur, Durgapur, West Bengal"

Do not put actual keys/passwords in this file or GitHub. Your previously pasted Neon password and Navamsha key should be rotated and the new values saved in Streamlit Secrets.

DEPLOY
1. Download and extract the ZIP.
2. Replace bittu.py and requirements.txt in your existing GitHub app repository with these versions; retain any other existing assets used by your repository.
3. Confirm Streamlit's Main file path is bittu.py.
4. Commit changes and wait for deployment.
5. Test the Map link and Panchang page.

TESTS / LIMITATIONS
- Python syntax and static location-wiring tests are included.
- No live Navamsha API request or production deployment was made during packaging. API schema/key validity and live results must be tested on Streamlit Cloud.
- If the API fails, Panchang values that cannot be sourced remain unavailable. Astral may calculate sunrise/sunset locally from coordinates when installed; it does not invent Tithi/Nakshatra or moonrise/moonset.
- Phase 2 does not import old SQLite records; that is a separate migration task.
