-- Phase 3 migration for an existing PostgreSQL/Neon database.
-- The app also creates this table automatically on startup.
CREATE TABLE IF NOT EXISTS japa_progress (
  email TEXT NOT NULL,
  temple TEXT NOT NULL CHECK (temple IN ('durga','shiva')),
  count INTEGER NOT NULL DEFAULT 0 CHECK (count >= 0 AND count <= 107),
  updated_at TEXT NOT NULL,
  PRIMARY KEY (email, temple)
);
