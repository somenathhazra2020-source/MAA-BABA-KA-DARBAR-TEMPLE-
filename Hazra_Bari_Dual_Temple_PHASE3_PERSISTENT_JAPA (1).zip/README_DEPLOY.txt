HAZRA BARI VIRTUAL DUAL TEMPLE — bittu.py
==========================================

MAIN STREAMLIT FILE
- bittu.py (lowercase, exact filename)

INCLUDED
- bittu.py: existing dual-temple devotional app, dynamic Panchang/astronomy lookup,
  Durga and Shiva Darshan, Akhand Diya indicators, Aarti, Bhog, Japa, Seva,
  Sankalp, reminders, rooms, history, and admin/analytics areas.
- mahadev_shiva.png: Shiva image asset.
- requirements.txt: Streamlit and Astral dependencies.
- SUPABASE_SCHEMA.sql: secure schema for the existing optional event mirror.

DEPLOY TO STREAMLIT CLOUD
1. Upload bittu.py, requirements.txt, mahadev_shiva.png and the other app assets
   from this folder to the root of the GitHub repository used by Streamlit.
2. Set the app's Main file path to bittu.py.
3. Ensure requirements.txt is committed; wait for dependency installation before rebooting.
4. Set DATABASE_URL in Streamlit Secrets to your rotated Neon PostgreSQL connection URL.
   The app now uses PostgreSQL for core account and devotional data when DATABASE_URL is
   configured. SQLite is retained only as a local-development fallback.
5. Keep PANCHANG_API_KEY and PANCHANG_API_URL in Streamlit Secrets. The expected URL is
   https://api.navamsha.in/api/v1/panchang/full.
6. Optional map secrets: HOME_LATITUDE = 23.493261 and HOME_LONGITUDE = 87.338363.
7. Astronomy times are requested for Durgapur coordinates and converted to Asia/Kolkata.
   If the source fails, missing values must remain unavailable rather than being replaced
   by hard-coded sample times.

DATABASE NOTES
- PostgreSQL tables are created automatically at app startup using CREATE TABLE IF NOT EXISTS.
- The previous Streamlit-hosted SQLite file is not included in this package, so this change
  does not import old accounts or devotional records automatically. Do not delete any old
  database/export until you have checked what data can be recovered.
- Test registration, logout/login, Khetri, Japa, Seva, wallet, Sankalp and history after deploy.
- The Neon connection string was shared in chat previously. Rotate its database password
  before deployment and replace DATABASE_URL in Streamlit Secrets. Never put it in GitHub.

OPTIONAL SUPABASE EVENT MIRROR
- Core account and devotional persistence now uses DATABASE_URL (Neon PostgreSQL), not Supabase.
- The optional Supabase event mirror is separate. Its service-role key, if used, must remain
  server-side in Streamlit Secrets only; never commit it to GitHub or browser-side HTML.
- Keep RLS enabled. Do not add public read/write policies for private event data.

SECURITY CHANGE
New passwords use salted PBKDF2-HMAC-SHA256. Existing legacy SHA-256 password hashes are
accepted at login and upgraded to the new format after successful authentication.

VALIDATION
Python syntax compilation has been run. Live Streamlit deployment, external API access,
Supabase credentials, audio playback, and cross-device synchronization must be tested in
Streamlit Cloud before treating them as verified.


PHASE 2 — PANCHANG & LOCATION RELIABILITY
-----------------------------------------
Optional Streamlit Secrets:
HOME_LATITUDE = 23.493261
HOME_LONGITUDE = 87.338363

# Only set these if the temple's Panchang location differs from the home pin:
# PANCHANG_LATITUDE = 23.493261
# PANCHANG_LONGITUDE = 87.338363
# PANCHANG_LOCATION_NAME = "Gopinathpur, Durgapur, West Bengal"

Panchang coordinates are selected in this order: explicit Panchang pair, home pair,
then Durgapur fallback. The app validates coordinate ranges. The home map continues
to use HOME_LATITUDE/HOME_LONGITUDE. Live external API responses were not verified
during this package build.
