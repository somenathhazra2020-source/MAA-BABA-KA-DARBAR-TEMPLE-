HAZRA BARI VIRTUAL DUAL TEMPLE — PHASE 3

Goal: persistent devotional progress. This package is based on the Phase 2 source.

Included changes:
1. Partial Japa Mala progress is stored in PostgreSQL when DATABASE_URL is configured, separately for Maa Durga and Mahadev Shiva.
2. Partial progress survives browser refresh/re-login on the same account when using the same hosted database.
3. Completed malas are recorded in japa_history and partial progress is cleared in the same database transaction.
4. Reset saves zero progress. A second temple does not overwrite the first temple's partial mala.
5. The app creates japa_progress automatically; PHASE3_MIGRATION.sql is supplied for review/manual migration if needed.

Deploy (manual; not deployed by this package):
- Keep a backup/copy of your current GitHub app first.
- Replace bittu.py and requirements.txt from this ZIP in the app repository. Keep existing image/assets and Secrets.
- Keep DATABASE_URL in Streamlit Secrets pointing to the intended persistent PostgreSQL database. Never paste credentials into chat or commit them.
- Commit to GitHub and wait for Streamlit Cloud to finish deploying.
- Test with a test account: chant 10 times in Maa Durga Japa, refresh/re-login, verify 10/108; switch to Shiva and verify its progress is independent; complete one mala and verify one history record.

Validation notes: static Python syntax checks and targeted source tests only. No live database connection, production deployment, credential check, or live app test was performed. Existing database records are not imported or deleted by this package.
